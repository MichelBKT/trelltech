function e(e,i,t,o){Object.defineProperty(e,i,{get:t,set:o,enumerable:!0,configurable:!0})}function i(e){return e&&e.__esModule?e.default:e}var t=("undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:"undefined"!=typeof window?window:"undefined"!=typeof global?global:{}).parcelRequire37b7,o=t.register;o("gx7I6",function(i,o){e(i.exports,"default",function(){return c});var n=t("4ZSso");t("91i6m");var r=t("8Bf3D"),l=t("bE8z6"),a=t("g6OTd"),s=t("7eeh4"),d=t("1TbRW"),c=({isEmbedded:e,oidcContext:i})=>e?null:(0,n.jsxs)(n.Fragment,{children:[(0,n.jsxs)("ul",{className:"fine-print",children:[(0,n.jsx)("li",{children:(0,n.jsx)(l.PrivacyPolicyLink,{isMobileLink:(0,s.isMobileOidc)(i)})}),(0,n.jsx)(r.default,{}),(0,n.jsx)("li",{children:(0,n.jsx)(l.UserNoticeLink,{isMobileLink:(0,s.isMobileOidc)(i)})})]}),(0,n.jsx)(d.RecaptchaNoticeContainer,{children:(0,n.jsx)(a.RecaptchaNotice,{})})]})}),o("68WXR",function(o,n){e(o.exports,"default",function(){return j});var r=t("4ZSso"),l=t("91i6m"),a=t("6T9dz"),s=t("6d87w"),d=t("dBq8m"),c=t("2aGBJ"),u=t("k8MAo"),g=t("8Bf3D"),f=t("64QTD"),p=t("gtKO2"),h=t("7eeh4"),x=t("1V2cH"),m=t("bqdjD"),v=t("9b70D"),b=t("1UkGo"),S=t("6OnpU"),j=({isMobileApp:e,oidcContext:t,showSocialLoginOnly:o})=>{let n=(0,c.useAppDispatch)(),j=(0,x.useAnalyticsClient)(),w="commercial"===(0,m.getCurrentPerimeter)(),L=i(d).parse(location.search),y=(0,l.useMemo)(()=>{let i=w&&(!e||(0,h.isOidcDisplayMode)(t,p.OidcDisplay.LoginWithRedirect));return"true"!==L.shide&&i},[w,e,t,L.shide]),M=(()=>{if(y){let e=(0,r.jsx)(a.default,{...v.LoginPageMessages.createAnAccount});return(0,r.jsx)(s.Link,{to:"/signup"+location.search,id:"signup",className:"primary-action",onClick:()=>{j.linkClickedEvent(b.pageId,"signUpLink")},children:e})}return null})();return o?(0,r.jsx)(f.default,{id:"use-a-different-login-method",spacing:"none",onClick:()=>{n((0,u.resetLoginForm)())},children:(0,r.jsx)(a.default,{...v.LoginPageMessages.socialFormUseDifferentLoginMethod})}):(0,r.jsxs)("ul",{children:[(0,r.jsx)("li",{children:(0,r.jsx)(S.ResetPasswordLink,{children:(0,r.jsx)(a.default,{id:"trouble.logging.in",defaultMessage:"Can't log in?"})})}),M&&(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(g.default,{}),(0,r.jsx)("li",{children:M})]})]})}}),o("bt1Sd",function(e,i){Object.defineProperty(e.exports,"__esModule",{value:!0}),e.exports.default=void 0;var o,n=(o=t("91i6m"))&&o.__esModule?o:{default:o},r=t("6crSb");let l=e=>n.default.createElement(r.Icon,Object.assign({dangerouslySetGlyph:'<svg width="24" height="24" viewBox="0 0 24 24" role="presentation"><g fill="currentColor" fill-rule="evenodd"><path d="M5 7v10h14V7H5zm14-2c1.1 0 2 .9 2 2v10c0 1.1-.9 2-2 2H5c-1.1 0-2-.9-2-2V7c0-1.1.9-2 2-2h14z" fill-rule="nonzero"/><path d="M5.498 6.5H3.124c.149.44.399.854.75 1.205l5.882 5.881a3.117 3.117 0 004.41 0l5.882-5.881c.35-.351.6-.765.749-1.205h-2.373l-5.672 5.672a1.119 1.119 0 01-1.583 0L5.498 6.5z"/></g></svg>'},e));l.displayName="EmailIcon",e.exports.default=l}),o("aiPk3",function(e,i){Object.defineProperty(e.exports,"__esModule",{value:!0}),e.exports.default=void 0;var o,n=(o=t("91i6m"))&&o.__esModule?o:{default:o},r=t("6crSb");let l=e=>n.default.createElement(r.Icon,Object.assign({dangerouslySetGlyph:'<svg width="24" height="24" viewBox="0 0 24 24" role="presentation"><path d="M4.02 19.23a1 1 0 001.18 1.18l3.81-.78-4.21-4.21-.78 3.81zM19.844 6.707l-2.12-2.122A1.997 1.997 0 0016.308 4c-.512 0-1.024.195-1.415.585l-9.757 9.758 4.95 4.95 9.757-9.758a2 2 0 000-2.828z" fill="currentColor" fill-rule="evenodd"/></svg>'},e));l.displayName="EditFilledIcon",e.exports.default=l}),o("8tnYQ",function(i,o){e(i.exports,"default",function(){return a});var n=t("fqDmW"),r=t("kLNLK");let l="24px";var a=(0,n.default).span`
  color: ${r.N500};
  height: ${l};
  width: ${l};

  + div input {
    margin-right: ${l};
  }
`}),o("9w0eB",function(i,o){e(i.exports,"default",function(){return u});var n=t("4ZSso"),r=t("91i6m"),l=t("gFwNN"),a=t("c1txK"),s=t("cJRdM"),d=t("leG06"),c=t("0wXBc"),u=({className:e,fieldError:i,isHidden:t,onChange:o,value:u})=>{let{formatMessage:g}=(0,d.default)(),f=(0,r.useRef)(null),p=(0,c.usePrevious)(t);(0,r.useEffect)(()=>{!t&&p&&f.current?.focus()},[t,p]);let h=i?(0,n.jsx)("span",{id:"password-error",children:i}):i;return(0,n.jsx)(l.default,{isHidden:t,className:e,children:(0,n.jsx)(a.default,{id:"password",testId:"password",name:"password",autoComplete:"current-password",placeholder:g(s.default.passwordPlaceholder),label:g(s.default.passwordLabel),autoFocus:!t,isLabelHidden:!0,onChange:o,isInvalid:!!i,invalidMessage:h,value:u,ref:f})})}}),o("lkawQ",function(i,o){e(i.exports,"default",function(){return d});var n=t("4ZSso");t("91i6m");var r=t("fqDmW"),l=t("6e88g"),a=t("gFwNN");let s=(0,r.default).div`
  box-sizing: border-box;
  height: 39px;
  overflow: hidden;
  padding: 10px 9px;
  text-overflow: ellipsis;
  white-space: nowrap;

  /* Offset FieldGroup negative margin. */
  margin-top: ${(0,l.gridSize)()}px;
`;var d=({value:e})=>(0,n.jsxs)(a.default,{children:[(0,n.jsx)(s,{title:e,children:e}),(0,n.jsx)("input",{"data-testid":"restricted-email-container",autoComplete:"username",type:"hidden",name:"username",value:e})]})}),o("lnbpL",function(i,o){e(i.exports,"default",function(){return d});var n=t("4ZSso");t("91i6m");var r=t("fqDmW"),l=t("kLNLK"),a=t("6e88g");let s=(0,r.default).div`
  color: ${l.N700};
  font-size: 13px;
  line-height: 17px;
  margin-bottom: 24px;
  margin-top: -4px;
  transform: rotateX(0deg);
  transform-origin: 50% 0;
  transition-property: visibility, height, margin-bottom, opacity, transform, padding;
  transition-duration: 0s, 0.2s, 0.2s, 0.2s, 0.2s;
  transition-timing-function: ease-in-out;
  text-align: center;

  &.hidden {
    height: 0;
    margin-bottom: 0;
    opacity: 0;
    padding: 0 ${2*(0,a.gridSize)()}px;
    pointer-events: none;
    transform: rotateX(-90deg);
    visibility: hidden;
  }
`;var d=({children:e,...i})=>(0,n.jsx)(s,{role:"alert",...i,className:i.isHidden?"hidden":"",children:e})}),o("gKURT",function(o,n){e(o.exports,"default",function(){return L});var r=t("4ZSso");t("91i6m");var l=t("6T9dz"),a=t("fqDmW"),s=t("6e88g"),d=t("kLNLK"),c=t("cLysE"),u=t("7cVVr"),g=t("eECIq"),f=t("fHCVH"),p=t("6jyTC"),h=t("c9rdI"),x=t("gtKO2");let m=(0,a.default).div`
  box-sizing: border-box;

  display: flex;
  flex-direction: column;
  align-items: flex-start;
  padding: ${1.5*(0,s.gridSize)()}px;

  border: 1px solid ${d.N50};
  border-radius: 3px;
`,v=(0,a.default).div`
  display: flex;
  align-self: center;
  justify-content: center;

  width: 100%;
  padding-bottom: ${1.5*(0,s.gridSize)()}px;
`,b=(0,a.default).div`
  font-weight: 600;
  font-size: 14px;
  line-height: ${3*(0,s.gridSize)()}px;
  color: ${d.N800};

  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
`,S=(0,a.default).img`
  height: ${3*(0,s.gridSize)()}px;
  padding-right: ${(0,s.gridSize)()}px;
`,j=e=>{switch(e){case x.SocialProvider.Google:return i(g);case x.SocialProvider.Microsoft:return i(f);case x.SocialProvider.Apple:return i(p);case x.SocialProvider.Slack:return i(h)}},w=({highlightedSocialProvider:e,handleGoogleLogin:i,handleMicrosoftLogin:t,handleAppleLogin:o,handleSlackLogin:n})=>{switch(e){case x.SocialProvider.Google:return i;case x.SocialProvider.Microsoft:return t;case x.SocialProvider.Apple:return o;case x.SocialProvider.Slack:return n}};var L=e=>{let{highlightedSocialProvider:i,email:t}=e,o=w(e);return(0,r.jsxs)(m,{"data-testid":"social-login-form",children:[(0,r.jsxs)(v,{children:[(0,r.jsx)(S,{src:j(i),alt:`${i} logo`}),t&&(0,r.jsx)(b,{children:t})]}),(0,r.jsx)(c.default,{isFullWidth:!0,id:"social-login-submit",appearance:"primary",onClick:o,children:(0,r.jsx)(l.default,{...u.default.continueWith,values:{socialProviderName:i.replace(/^./,e=>e.toUpperCase())}})})]})}}),o("7cVVr",function(i,o){e(i.exports,"default",function(){return n});var n=(0,t("j5RJC").defineMessages)({continueWith:{id:"social.login.form.continue-button",defaultMessage:"Continue with {socialProviderName}",description:"Button label that is a CTA for users to continue logging in using the selected social provider."}})}),o("eECIq",function(e,i){e.exports=new URL("google-logo.5867462c.svg",import.meta.url).toString()}),o("fHCVH",function(e,i){e.exports=new URL("microsoft-logo.c73d8dca.svg",import.meta.url).toString()}),o("6jyTC",function(e,i){e.exports=new URL("apple-logo.54e0d711.svg",import.meta.url).toString()}),o("c9rdI",function(e,i){e.exports=new URL("slack-logo.5d730c10.svg",import.meta.url).toString()}),o("k3QGO",function(i,o){e(i.exports,"default",function(){return l});var n=t("4ZSso");t("91i6m");var r=t("j7UeI"),l=({isEmbedded:e,isSocialBlocked:i,envSupportsSocialLogin:t,onGoogleLogin:o,onMicrosoftLogin:l,onAppleLogin:a,onSlackLogin:s})=>!t||e||i?null:(0,n.jsx)(r.default,{handleGoogleLogin:o,handleMicrosoftLogin:l,handleAppleLogin:a,handleSlackLogin:s})});
//# sourceMappingURL=defaultPage.8f68dcd3.js.map
