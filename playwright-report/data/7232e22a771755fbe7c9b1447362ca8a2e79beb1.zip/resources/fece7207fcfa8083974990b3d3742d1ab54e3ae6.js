function e(e){return e&&e.__esModule?e.default:e}function i(e,i,t,a){Object.defineProperty(e,i,{get:t,set:a,enumerable:!0,configurable:!0})}var t=("undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:"undefined"!=typeof window?window:"undefined"!=typeof global?global:{}).parcelRequire37b7,a=t.register;a("7Clnv",function(a,n){i(a.exports,"default",function(){return H});var l=t("4ZSso"),s=t("91i6m"),r=t("6T9dz"),o=t("leG06"),d=t("9OWP7"),u=t("fqDmW"),c=t("bt1Sd"),f=t("kLNLK"),g=t("6e88g"),p=t("gFwNN"),m=t("dmC2D"),x=t("9w0eB"),h=t("lkawQ"),b=t("cLysE"),j=t("31nHY"),w=t("lnbpL"),v=t("j7UeI"),C=t("jthWj"),k=t("gtKO2"),y=t("fYxRW"),E=t("1V2cH"),L=t("1UkGo"),M=t("cZAbO"),S=t("6eNI5"),I=t("cs6gC"),R=t("brCu8"),T=t("83IjZ"),N=t("1a5r2"),U=t("9X0U9"),A=t("c32T7"),D=t("9MKJ7");let P=(0,u.default).div`
  align-items: center;
  color: ${f.N90};
  display: flex;
  height: 40px;
  justify-content: space-between;
  padding: 0 8px;
`,F=(0,u.default).form`
  margin: 0;
`,O=(0,u.default).div`
  margin-bottom: ${(0,g.gridSize)()}px;
`;var H=({application:i,email:t,error:a,fieldErrors:n,info:u,isLoading:f,isPasswordlessAllowed:g,isRedirecting:H,isSecondStep:$,isCheckUsernameLoading:B,onContinue:K,onEditEmail:W,onEmailChange:z,onFormClick:_,onLogIn:q,onPasswordlessLogIn:Z,onValidationError:G,pageId:V,redirectType:Y,restrictedEmail:Q,showRememberMeCheckbox:X,rememberMeChecked:J,onToggleRememberMeCheckbox:ee})=>{let ei=(0,o.default)(),et=(0,R.useTranslateFormErrorIfAvailable)(n.email),ea=(0,E.useAnalyticsClient)(),[en,el]=(0,s.useState)(""),[es,er]=(0,s.useState)("submit"),eo=(0,s.useRef)(null),[ed,eu]=(0,s.useState)(null),ec=(0,s.useCallback)(()=>{el(""),eu(null),W()},[W]),{captchaValue:ef,isRequired:eg}=(0,S.useLoginTooManyAttemptsRecaptchaContext)(),ep=async e=>{e.preventDefault();let i=t.trim(),a=""===i,n=""===en;if(!f){if(a){eo.current?.focus();let e=eh(C.default.emailEmpty);ea.errorShownEvent(L.pageId,"validationError"),G({email:e})}er("submit"),$?(ea.buttonClickedEvent(V,"login"),n?eu(eh(C.default.passwordEmpty)):a||q(i,en)):(ea.buttonClickedEvent(V,"continueToLogin"),a||K(i))}},em=async()=>{let e=t.trim();!f&&e&&(er("passwordless"),Z(e))},ex=(0,s.useCallback)(e=>{ed&&eu(null),el(e.currentTarget.value)},[ed,eu,el]);(0,s.useEffect)(()=>{ea.stopInitialLoadApdexEvent("viewLoginPage")},[ea]);let{formatMessage:eh}=ei;return(0,l.jsxs)("div",{children:[a&&(0,l.jsx)(j.default,{children:a?.message}),(0,l.jsxs)("span",{children:[" ",(()=>{let{formatMessage:e}=ei,t=i?y.applications[i].name:"Product",a="login-info-test-id";if(u)switch(u.code){case"migratingExistingUser":{let i=e(C.default.migrateAccountInfo,{application:t});return(0,l.jsx)(w.default,{id:"login-info","data-testid":a,children:i})}case"existingUserSignupAttempt":{let i=e(C.default.existingUserSignupAttemptInfo);return(0,l.jsx)(w.default,{id:"login-info","data-testid":a,children:i})}default:return(0,l.jsx)(w.default,{id:"login-info","data-testid":a,isHidden:!0,children:" "})}})()," "]}),(0,l.jsxs)(F,{id:"form-login","data-testid":"form-login",onSubmit:ep,onClick:_,children:[(0,l.jsxs)(O,{children:[Q||Y===k.CheckUserNameRedirectType.Sso?(0,l.jsx)(h.default,{value:t}):(0,l.jsx)(m.default,{isReadOnly:$||f,fieldError:(()=>{switch(n.email){case"unknown":return ei.formatMessage(C.default.unexpectedErrorHappened);case"rate_limit_exceeded_message":return ei.formatMessage(C.default.rateLimitErrorMessage);default:return et}})(),onChange:z,value:t,onEmailClick:ec,placeholderOverride:eh(C.default.emailPlaceholder),inputRef:eo}),(0,l.jsx)(x.default,{isHidden:!$,fieldError:ed||void 0,onChange:ex,value:en,className:`field-group password-field ${$?"expanded":"hidden"}`}),(0,l.jsx)(M.LoginRecaptcha,{}),(0,l.jsx)(I.LoginMarketingConsent,{}),X&&Y!==k.CheckUserNameRedirectType.Sso&&(0,l.jsx)(U.default,{paddingBlockStart:"space.100",paddingBlockEnd:"space.100",children:(0,l.jsxs)(A.default,{direction:"row",gap:"space.100",alignItems:"center",children:[(0,l.jsx)(T.default,{testId:"remember-me-checkbox",isChecked:J,onClick:ee,name:"remember",label:(0,l.jsx)(r.default,{...C.default.rememberMeCheckboxLabel}),isDisabled:"submit"===es&&(!!H||f||B)}),(0,l.jsx)(D.default,{position:"right",content:(0,l.jsx)(r.default,{...C.default.rememberMeTooltip}),children:(0,l.jsx)(A.default,{alignItems:"center",children:(0,l.jsx)(e(N),{label:eh(C.default.rememberMeTooltip),size:"small"})})})]})})]}),Y===k.CheckUserNameRedirectType.Sso?(0,l.jsxs)(P,{children:[(0,l.jsx)(r.default,{id:"login.form.opening.sso",defaultMessage:"Opening your single sign-on provider"}),(0,l.jsx)(d.default,{})]}):(0,l.jsx)(b.default,{appearance:"primary",id:"login-submit",type:"submit",isFullWidth:!0,isDisabled:$&&eg&&!ef,isLoading:"submit"===es&&(!!H||f||B),children:$?g?(0,l.jsx)(r.default,{id:"common.login.with.password",defaultMessage:"Log in with password"}):(0,l.jsx)(r.default,{id:"common.login",defaultMessage:"Log in"}):(0,l.jsx)(r.default,{id:"login.form.continue",defaultMessage:"Continue"})}),(0,l.jsx)(p.default,{isHidden:!$||!g,children:(0,l.jsx)(v.StyledSocialLoginButton,{id:"passwordless-button",iconBefore:(0,l.jsx)(e(c),{label:"email"}),iconAfter:(0,l.jsx)("span",{style:{width:24}}),isFullWidth:!0,advisoryEnabled:!1,onClick:em,isLoading:"passwordless"===es&&(!!H||f),isDisabled:eg&&!ef||f||H,children:(0,l.jsx)(r.default,{id:"login.form.passwordless.button",defaultMessage:"Log in with email"})})})]})]})}}),a("dmC2D",function(a,n){i(a.exports,"default",function(){return v});var l=t("4ZSso"),s=t("91i6m"),r=t("fqDmW"),o=t("aiPk3"),d=t("h89s9"),u=t("kLNLK"),c=t("6e88g"),f=t("gFwNN"),g=t("8tnYQ"),p=t("26Riy"),m=t("gaHKK"),x=t("leG06"),h=t("0wXBc");let b=(0,r.default).div`
  margin-top: ${(0,c.gridSize)()}px;
  border: 1px solid rgba(255, 255, 255, 0);
  border-radius: 5px;
  box-sizing: border-box;
  cursor: pointer;
  height: 39px;
  outline: none;
  padding: 9px 32px 9px 8px;
  transition: background-color 0.2s ease-in-out, border-color 0.2s ease-in-out;

  &:hover {
    background: ${u.N10};
    border-color: ${u.N20};
  }
  &:focus {
    border-color: ${u.B100};
    border-width: 2px;
    padding: 8px 31px 8px 7px;
  }

  ${(0,p.media).handheld`
    font-size: 16px;
  `}
`,j=(0,r.default).span`
  display: flex;
  overflow: hidden;
  white-space: nowrap;
`,w=(0,r.default)(g.default)`
  float: right;
  margin-top: -22px;
  margin-right: -27px;
`;var v=({fieldError:i,isReadOnly:t,onChange:a,onEmailClick:n,placeholderOverride:r,value:u,inputRef:c})=>{let{formatMessage:g}=(0,x.default)(),p=(0,h.usePrevious)(t);(0,s.useEffect)(()=>{!t&&p&&c.current?.focus()},[t,p,c]);let v=r||g(m.default.loginFormUsernamePlaceholder);return(0,l.jsx)(f.default,{children:t?(0,l.jsxs)(b,{onClick:n,tabIndex:0,onKeyDown:e=>{"Enter"===e.key&&(e.preventDefault(),n())},children:[(0,l.jsx)(j,{children:u}),(0,l.jsx)(w,{children:(0,l.jsx)(e(o),{label:""})})]}):(0,l.jsx)(d.default,{id:"username",testId:"username",name:"username",autoComplete:"username",type:"email",placeholder:v,label:g(m.default.loginFormUsernameLabel),autoFocus:!t,isLabelHidden:!0,onChange:e=>{a(e.currentTarget.value)},isInvalid:!!i,invalidMessage:i,value:u,ref:c})})}});
//# sourceMappingURL=defaultPage.98de4956.js.map
